// 尾道一日遊 — 行程資料 (2026/6/1 週一)
// 時間以「當日分鐘數」表示，方便計算目前進度。
window.TRIP = {
  meta: {
    title: '尾道 山海朝食一日遊',
    subtitle: '岡山 → 尾道 ・ 新幹線對號座版',
    dateLabel: '2026 / 6 / 1',
    weekday: '週一',
    routeJp: '岡山 ⇄ 尾道',
    // 6 月初瀨戶內海的季節參考（非即時氣象）
    weather: { label: '晴時多雲', tempHi: 26, tempLo: 18, note: '瀨戶內海・初夏' },
    sunsetMin: 19 * 60 + 8, // 約 19:08 日落
    goldenStart: 17 * 60,   // 黃金時刻 17:00 起
    mapUrl: 'https://www.google.com/maps/dir/Okayama+Station,+%EF%BC%91-1+%E9%A7%85%E5%85%83%E7%94%BA,+%E5%8C%97%E5%8C%BA+%E5%B2%A1%E5%B1%B1%E5%B8%82+%E5%B2%A1%E5%B1%B1%E7%9C%8C,+Japan/Onomichi+Station,+%EF%BC%91%E4%B8%81%E7%9B%AE-%EF%BC%91+%E6%9D%B1%E5%BE%A1%E6%89%80%E7%94%BA,+%E5%B0%BE%E9%81%93%E5%B8%82+%E5%BA%83%E5%B3%B6%E7%9C%8C,+Japan/'
  },

  // kind: 'spot' = 完整景點卡 ; 'transit' = 交通/轉乘精簡段
  stops: [
    {
      id: 's01', kind: 'spot', icon: 'home', start: '08:00', end: '08:00',
      title: '岡山出發', jp: '岡山駅', map: '岡山駅',
      plan: '準時從住處出發，散步前往 JR 岡山站。',
      tip: '出發前最後確認。',
      risk: '檢查手機、球鞋、防曬乳與防蚊液是否帶齊。'
    },
    {
      id: 's02', kind: 'spot', icon: 'ticket', start: '08:20', end: '08:35',
      title: '岡山站購票', jp: '岡山駅 みどりの券売機', map: '岡山駅',
      plan: '到綠色售票機買「岡山 ⇄ 尾道」指定席聯絡票，去回程一次買齊。',
      tip: '在岡山站一次把去回程對號座都劃好，回程最省心。',
      risk: '【省時關鍵】回程劃位避免傍晚臨櫃排隊。',
      ticket: {
        title: '對號座劃位',
        rows: [
          { dir: '去程', train: '回聲號 Kodama 841', time: '08:44 發', seat: '指定席' },
          { dir: '回程', train: '櫻花號 Sakura 562', time: '18:50 發', seat: '指定席' }
        ]
      }
    },
    {
      id: 's03', kind: 'transit', icon: 'shinkansen', start: '08:44', end: '09:00',
      title: '岡山 → 福山', jp: '山陽新幹線',
      plan: '山陽新幹線・回聲號（Kodama 841）指定席。',
      risk: '避開週一普通車通勤潮，安靜車廂內舒適補眠。',
      transit: { line: '山陽新幹線 こだま841', dur: '16 分', seat: '指定席', dirNote: '岡山 → 福山' }
    },
    {
      id: 's04', kind: 'transit', icon: 'transfer', start: '09:00', end: '09:09',
      title: '福山站轉乘', jp: '福山駅 乗換',
      plan: '走「在來線轉乘閘口」（免出站），直接下到山陽本線月台。',
      risk: '9 分鐘很充裕。看板找「三原 / 糸崎」方向。',
      transit: { line: '在來線轉乘閘口', dur: '9 分', seat: '免出站', dirNote: '往 三原・糸崎 方向' }
    },
    {
      id: 's05', kind: 'transit', icon: 'train', start: '09:09', end: '09:28',
      title: '福山 → 尾道', jp: '山陽本線 普通',
      plan: 'JR 山陽本線普通車。',
      risk: '福山是大站，此時段普通車通常有空位可坐。',
      transit: { line: 'JR 山陽本線 普通', dur: '19 分', seat: '自由座', dirNote: '福山 → 尾道' }
    },
    {
      id: 's06', kind: 'spot', icon: 'sea', start: '09:28', end: '09:35',
      title: '抵達尾道站', jp: '尾道駅', map: '尾道駅',
      plan: '輕裝出站。大件行李立刻鎖進車站 Coin Locker。',
      tip: '從這裡開始一整天都是步行。',
      risk: '【地形警示】尾道全天階梯坡道，切勿攜帶行李箱上山。'
    },
    {
      id: 's07', kind: 'spot', icon: 'coffee', start: '09:30', end: '10:15',
      title: '尾道朝食時光', jp: '喫茶リオ', map: '喫茶リオ 尾道',
      plan: '步行 7 分前往老派純喫茶【喫茶リオ】，點經典 Morning Set：烤吐司、水煮蛋、黑咖啡。',
      tip: '昭和氛圍的純喫茶，慢慢吃完再上山。',
      risk: '【週一公休過濾】本店週一正常營業。老店請準備日圓現金。'
    },
    {
      id: 's08', kind: 'spot', icon: 'cablecar', start: '10:15', end: '11:30',
      title: '纜車上山 ＆ PEAK 展望台', jp: '千光寺山ロープウェイ / 展望台 PEAK', map: '千光寺頂展望台 PEAK',
      plan: '步行至纜車站搭單程纜車（¥500）上山，直奔「PEAK」木造展望台俯瞰尾道水道。',
      tip: '單程上山，下山走石階順遊千光寺。',
      risk: '【最佳攝影】接近中午頂級順光，拍出最通透飽滿的瀨戶內海靛藍。',
      fare: '¥500 單程'
    },
    {
      id: 's09', kind: 'spot', icon: 'temple', start: '11:30', end: '12:15',
      title: '千光寺參拜 → 下山', jp: '千光寺', map: '千光寺',
      plan: '沿山路石階散步下山，參拜依山而建的朱紅正殿，俯瞰夾縫海景。',
      tip: '邊走邊拍，慢慢下到山腳。',
      risk: '石階落差大，下山注意腳步，務必穿防滑運動鞋。'
    },
    {
      id: 's10', kind: 'spot', icon: 'ramen', start: '12:15', end: '13:15',
      title: '午餐：經典尾道拉麵', jp: '麺処 響 / 喰海', map: '尾道ラーメン 麺処 響',
      plan: '前往【麵處 響】或【喰海】享用醬油拉麵（需先投幣買食券）。',
      tip: '兩家擇一，先看排隊狀況決定。',
      risk: '12:15 完美避開 11:30 第一波開門的排隊潮。'
    },
    {
      id: 's11', kind: 'spot', icon: 'cat', start: '13:15', end: '14:15',
      title: '探險：貓之細道', jp: '猫の細道', map: '猫の細道 尾道',
      plan: '鑽入山腰綠蔭小徑，尋找藝術家彩繪的「福石貓」與慵懶街貓。',
      tip: '放慢腳步，沿途都是貓與藝術小物。',
      risk: '午後貓咪愛在陰涼處打盹。樹叢多，請隨手塗防蚊液。'
    },
    {
      id: 's12', kind: 'spot', icon: 'shop', start: '14:15', end: '15:30',
      title: '昭和復古：本通商店街', jp: '尾道本通り商店街 / 大和湯', map: '尾道本通り商店街',
      plan: '漫步 1.2 公里商店街，朝聖百年錢湯改建的文創選物店【大和湯】。',
      tip: '挑廣島檸檬、蜜柑相關伴手禮與文創小物。',
      risk: '商店街店家多半下午營業，採買最佳時段。'
    },
    {
      id: 's13', kind: 'spot', icon: 'icecream', start: '15:30', end: '16:15',
      title: '下午茶：KARASAWA 最中餅', jp: 'からさわ アイスモナカ', map: 'からさわ 尾道',
      plan: '前往海邊老舖點現做的冰淇淋最中餅（アイスモナカ）。',
      tip: '拿到後直接過馬路到海邊長椅吃，體驗在地慢活。',
      risk: '現做易融，建議外帶後盡快享用。'
    },
    {
      id: 's14', kind: 'spot', icon: 'sunset', start: '16:15', end: '17:45',
      title: '文創夕陽：ONOMICHI U2', jp: 'ONOMICHI U2', map: 'ONOMICHI U2',
      plan: '步行前往西側海運倉庫，逛設計選物與單車選品；17:00 後移步露天木棧道。',
      tip: '本日壓軸，把海景留到最後。',
      risk: '【魔幻時刻】17:00–17:45 靜靜欣賞夕陽將瀨戶內海染成金黃。'
    },
    {
      id: 's15', kind: 'transit', icon: 'walk', start: '17:45', end: '18:14',
      title: '返回尾道站', jp: '尾道駅',
      plan: '從 U2 沿平地碼頭輕鬆步行 5 分回到 JR 尾道站。',
      risk: '無回頭路動線收尾。肚子餓的話，車站前拉麵店有開。',
      transit: { line: '步行・平地碼頭', dur: '5 分', seat: '徒步', dirNote: 'U2 → 尾道駅' }
    },
    {
      id: 's16', kind: 'transit', icon: 'train', start: '18:14', end: '18:33',
      title: '尾道 → 福山', jp: '山陽本線 普通',
      plan: 'JR 山陽本線普通車（往相生方向）返回福山站。',
      risk: '車程僅 19 分鐘，轉瞬即達。',
      transit: { line: 'JR 山陽本線 普通', dur: '19 分', seat: '自由座', dirNote: '往 相生 方向' }
    },
    {
      id: 's17', kind: 'transit', icon: 'transfer', start: '18:33', end: '18:50',
      title: '福山站轉乘', jp: '福山駅 乗換',
      plan: '走轉乘閘口回到新幹線月台。可在月台商店買瓶廣島檸檬沙瓦。',
      risk: '17 分鐘極度從容，在月台稍作休息。',
      transit: { line: '新幹線轉乘閘口', dur: '17 分', seat: '免出站', dirNote: '在來線 → 新幹線' }
    },
    {
      id: 's18', kind: 'transit', icon: 'shinkansen', start: '18:50', end: '19:06',
      title: '福山 → 岡山', jp: '山陽新幹線',
      plan: '山陽新幹線・櫻花號（Sakura 562）指定席。',
      risk: '走了一整天，回程在寬敞對號座上徹底放鬆，19:06 抵達岡山。',
      transit: { line: '山陽新幹線 さくら562', dur: '16 分', seat: '指定席', dirNote: '福山 → 岡山' }
    }
  ],

  checklist: [
    { id: 'c1', label: '防滑、好走的運動鞋', note: '尾道多石階與坡道' },
    { id: 'c2', label: '足量日圓現金', note: '老派喫茶店與拉麵食券機不支援電子支付' },
    { id: 'c3', label: '防蚊液', note: '貓之細道樹叢較多' },
    { id: 'c4', label: '防曬乳 ＆ 墨鏡', note: '海邊與展望台日照強' },
    { id: 'c5', label: '手機充飽電 ＆ 行動電源', note: '全天導航與拍照' }
  ]
};
