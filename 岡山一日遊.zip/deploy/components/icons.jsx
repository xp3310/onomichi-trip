// 簡潔線性圖示集
const ICON_PATHS = {
  home: '<path d="M3 11l9-7 9 7"/><path d="M5 10v10h14V10"/>',
  ticket: '<rect x="3" y="6" width="18" height="12" rx="2"/><path d="M3 11a2 2 0 0 0 0 2"/><path d="M21 11a2 2 0 0 1 0 2"/><path d="M14 6v12" stroke-dasharray="2 2"/>',
  shinkansen: '<path d="M5 4h14a0 0 0 0 1 0 0v9a4 4 0 0 1-4 4H9a4 4 0 0 1-4-4V4z"/><path d="M5 9h14"/><circle cx="9" cy="13" r="1"/><circle cx="15" cy="13" r="1"/><path d="M8 21l-2 0"/><path d="M16 21l2 0"/><path d="M9 17l-1 3"/><path d="M15 17l1 3"/>',
  transfer: '<path d="M4 9h13l-3-3"/><path d="M20 15H7l3 3"/>',
  train: '<rect x="6" y="3" width="12" height="14" rx="3"/><path d="M6 10h12"/><circle cx="9" cy="14" r="1"/><circle cx="15" cy="14" r="1"/><path d="M8 17l-2 4"/><path d="M16 17l2 4"/>',
  sea: '<path d="M3 8c2 0 2 2 4.5 2S10 8 12 8s2 2 4.5 2S19 8 21 8"/><path d="M3 14c2 0 2 2 4.5 2S10 14 12 14s2 2 4.5 2S19 14 21 14"/>',
  coffee: '<path d="M5 8h11v5a4 4 0 0 1-4 4H9a4 4 0 0 1-4-4V8z"/><path d="M16 9h2a2 2 0 0 1 0 4h-2"/><path d="M8 3v2M11 3v2"/>',
  cablecar: '<path d="M3 5l18-2"/><path d="M12 4v4"/><rect x="6" y="8" width="12" height="8" rx="2"/><path d="M6 12h12"/>',
  temple: '<path d="M3 8h18l-2-3H5z"/><path d="M5 8v11M19 8v11M9 19v-6h6v6"/><path d="M3 19h18"/>',
  ramen: '<path d="M4 10h16a8 8 0 0 1-16 0z"/><path d="M9 6c0-1 1-1 1-2M12 6c0-1 1-1 1-2M15 6c0-1 1-1 1-2"/><path d="M3 20h18"/>',
  cat: '<path d="M5 9l-1-5 4 3a7 7 0 0 1 8 0l4-3-1 5"/><path d="M5 9a7 7 0 0 0 14 0"/><circle cx="9.5" cy="12" r=".6"/><circle cx="14.5" cy="12" r=".6"/><path d="M12 14v1M10 15.5h4"/>',
  shop: '<path d="M4 8h16l-1 12H5z"/><path d="M8 8a4 4 0 0 1 8 0"/>',
  icecream: '<path d="M8 9a4 4 0 0 1 8 0"/><path d="M8 9h8l-4 11z"/><path d="M9.5 13h5M10.5 16h3"/>',
  sunset: '<path d="M12 4v5M5 11l1.5 1.5M19 11l-1.5 1.5M3 18h18"/><path d="M8 18a4 4 0 0 1 8 0"/><path d="M21 21H3"/>',
  walk: '<circle cx="13" cy="5" r="1.5"/><path d="M13 8l-2 4 3 2 1 6"/><path d="M11 12l-3 1-2 4"/><path d="M14 14l3 1"/>'
};

function Icon({ name, size = 16, stroke = 1.8, className = '' }) {
  const inner = ICON_PATHS[name] || ICON_PATHS.sea;
  return (
    <svg
      className={className}
      width={size} height={size} viewBox="0 0 24 24"
      fill="none" stroke="currentColor" strokeWidth={stroke}
      strokeLinecap="round" strokeLinejoin="round"
      dangerouslySetInnerHTML={{ __html: inner }}
    />
  );
}

// 其他 UI 圖示
function UIIcon({ name, size = 16, stroke = 1.8 }) {
  const paths = {
    chevron: '<path d="M6 9l6 6 6-6"/>',
    pin: '<path d="M12 21s-7-6.5-7-11a7 7 0 0 1 14 0c0 4.5-7 11-7 11z"/><circle cx="12" cy="10" r="2.5"/>',
    check: '<path d="M5 12l4 4 10-10"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M19 5l-1.5 1.5M6.5 17.5L5 19"/>',
    sunset2: '<path d="M12 3v6M5.5 10.5 7 12M18.5 10.5 17 12M2 16h20"/><path d="M7 16a5 5 0 0 1 10 0"/><path d="M4 20h16"/>',
    arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
    locate: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/>'
  };
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round"
      dangerouslySetInnerHTML={{ __html: paths[name] || paths.pin }} />
  );
}

Object.assign(window, { Icon, UIIcon });
