// 主程式
const { useState, useEffect, useRef, useCallback } = React;

function toMin(hhmm) {
  const [h, m] = hhmm.split(':').map(Number);
  return h * 60 + m;
}
function fmtMin(min) {
  const h = Math.floor(min / 60), m = min % 60;
  return String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0');
}

// 依目前時間決定每一站狀態
function computeStatus(stops, nowMin) {
  const starts = stops.map(s => toMin(s.start));
  const lastEnd = toMin(stops[stops.length - 1].end);
  let activeIdx = -1;
  if (nowMin >= starts[0] && nowMin < lastEnd) {
    for (let i = 0; i < stops.length; i++) {
      const next = i + 1 < stops.length ? starts[i + 1] : lastEnd;
      if (nowMin >= starts[i] && nowMin < next) { activeIdx = i; break; }
    }
  }
  const phase = nowMin < starts[0] ? 'pre' : (nowMin >= lastEnd ? 'post' : 'live');
  return { activeIdx, phase, starts, lastEnd };
}

function NowStrip({ stops, status, nowMin }) {
  const { activeIdx, phase, starts, lastEnd } = status;
  let txt;
  if (phase === 'pre') {
    const mins = starts[0] - nowMin;
    txt = <>距離 <b>出發</b> 還有 {mins} 分鐘 <span className="sub">・ 08:00 岡山</span></>;
  } else if (phase === 'post') {
    txt = <><b>行程已圓滿結束</b> <span className="sub">・ 辛苦了，回程好眠</span></>;
  } else {
    const cur = stops[activeIdx];
    const nextStart = activeIdx + 1 < stops.length ? starts[activeIdx + 1] : lastEnd;
    const left = nextStart - nowMin;
    const nxt = stops[activeIdx + 1];
    txt = <>現在 <b>{cur.title}</b>{nxt && <span className="sub"> ・ {left} 分後 → {nxt.title}</span>}</>;
  }
  return (
    <div className="now-strip">
      <span className="now-strip__pulse"></span>
      <div className="now-strip__txt">{txt}</div>
    </div>
  );
}

function TopBar({ meta, stops, status, nowMin }) {
  const goldenH = fmtMin(meta.goldenStart), sunsetH = fmtMin(meta.sunsetMin);
  return (
    <header className="topbar">
      <div className="topbar__title">{meta.title}</div>
      <div className="topbar__row">
        <div className="topbar__route">{meta.routeJp}</div>
        <div className="topbar__date">
          <b>{meta.dateLabel}</b><span className="topbar__wk">{meta.weekday}</span>
        </div>
      </div>

      <NowStrip stops={stops} status={status} nowMin={nowMin} />

      <div className="hint-row">
        <div className="hint">
          <UIIcon name="sun" size={20} />
          <div>
            <div className="hint__k">季節氣候參考</div>
            <div className="hint__v">{meta.weather.label} <small>{meta.weather.tempLo}–{meta.weather.tempHi}°C</small></div>
          </div>
        </div>
        <div className="hint">
          <UIIcon name="sunset2" size={20} />
          <div>
            <div className="hint__k">黃金時刻 / 日落</div>
            <div className="hint__v">{goldenH} 起 <small>日落 {sunsetH}</small></div>
          </div>
        </div>
      </div>
    </header>
  );
}

function Timeline({ stops, status, refMap }) {
  return (
    <div className="timeline">
      {stops.map((s, i) => {
        const isNow = i === status.activeIdx;
        const isDone = status.phase !== 'pre' && i < status.activeIdx ||
          (status.phase === 'post');
        const cls = 'tl-item' + (isNow ? ' is-now' : '') + (isDone && !isNow ? ' is-done' : '');
        const st = isNow ? 'now' : (isDone ? 'done' : 'todo');
        return (
          <div className={cls} key={s.id} ref={el => { if (el) refMap.current[s.id] = el; }}>
            <span className="tl-node"><Icon name={s.icon} size={13} stroke={2} /></span>
            {s.kind === 'spot'
              ? <SpotCard s={s} status={st} openByDefault={isNow} />
              : <TransitCard s={s} status={st} openByDefault={isNow} />}
          </div>
        );
      })}
    </div>
  );
}

function Checklist({ items }) {
  const KEY = 'onomichi-checklist-v1';
  const [done, setDone] = useState(() => {
    try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch (e) { return {}; }
  });
  const toggle = (id) => setDone(d => {
    const n = { ...d, [id]: !d[id] };
    try { localStorage.setItem(KEY, JSON.stringify(n)); } catch (e) {}
    return n;
  });
  return (
    <div className="checklist">
      {items.map(it => (
        <div className={'check' + (done[it.id] ? ' on' : '')} key={it.id} onClick={() => toggle(it.id)}>
          <span className="check__box"><UIIcon name="check" size={14} stroke={3} /></span>
          <div className="check__main">
            <div className="check__label">{it.label}</div>
            <div className="check__note">{it.note}</div>
          </div>
        </div>
      ))}
    </div>
  );
}

function App() {
  const { meta, stops, checklist } = window.TRIP;
  const refMap = useRef({});
  const demoNow = (() => {
    const p = new URLSearchParams(location.search).get('now');
    return p && /^\d{1,2}:\d{2}$/.test(p) ? toMin(p) : null;
  })();
  const [nowMin, setNowMin] = useState(() => {
    if (demoNow != null) return demoNow;
    const d = new Date(); return d.getHours() * 60 + d.getMinutes();
  });
  const [showJump, setShowJump] = useState(false);

  // 每 30 秒刷新目前時間（demo 模式不刷新）
  useEffect(() => {
    if (demoNow != null) return;
    const t = setInterval(() => {
      const d = new Date(); setNowMin(d.getHours() * 60 + d.getMinutes());
    }, 30000);
    return () => clearInterval(t);
  }, []);

  const status = computeStatus(stops, nowMin);

  const scrollToNow = useCallback(() => {
    if (status.activeIdx < 0) return;
    const id = stops[status.activeIdx].id;
    const el = refMap.current[id];
    if (el) {
      const y = el.getBoundingClientRect().top + window.scrollY - 150;
      window.scrollTo({ top: y, behavior: 'smooth' });
    }
  }, [status.activeIdx, stops]);

  // 載入時自動定位到「現在」
  useEffect(() => {
    if (status.activeIdx >= 0) {
      const id = requestAnimationFrame(() => setTimeout(scrollToNow, 350));
      return () => cancelAnimationFrame(id);
    }
  }, []); // eslint-disable-line

  // 監控捲動：離開現在卡片時顯示「跳到現在」
  useEffect(() => {
    const onScroll = () => {
      if (status.activeIdx < 0) { setShowJump(false); return; }
      const el = refMap.current[stops[status.activeIdx].id];
      if (!el) return;
      const r = el.getBoundingClientRect();
      setShowJump(r.bottom < 80 || r.top > window.innerHeight - 40);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener('scroll', onScroll);
  }, [status.activeIdx, stops]);

  return (
    <div className="shell">
      <TopBar meta={meta} stops={stops} status={status} nowMin={nowMin} />

      <Timeline stops={stops} status={status} refMap={refMap} />

      <div className="section-head">
        <h2>隨身 Checklist</h2><span className="ln"></span>
      </div>
      <Checklist items={checklist} />

      <a className="cta" href={meta.mapUrl} target="_blank" rel="noopener">
        <span className="cta__ic"><UIIcon name="locate" size={20} stroke={2} /></span>
        <div>
          <div className="cta__t">全程 Google 地圖動線</div>
          <div className="cta__s">岡山駅 → 尾道駅 ・ 一鍵開啟導航</div>
        </div>
        <span className="cta__arrow"><UIIcon name="arrow" size={20} /></span>
      </a>

      <div className="footer">
        <div className="sea-rule"></div>
        <div>尾道 山海朝食一日遊 ・ <b>{meta.dateLabel} {meta.weekday}</b></div>
        <div>Planner ・ Tasker ・ Implementer ・ Reviewer 協同校準動線</div>
      </div>

      <button className={'jump-now' + (showJump ? ' show' : '')} onClick={scrollToNow}>
        <UIIcon name="locate" size={15} stroke={2.2} />跳到現在
      </button>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
