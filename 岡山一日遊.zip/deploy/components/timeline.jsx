// 時間軸卡片元件
const { useState } = React;

function mapHref(query) {
  return 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(query);
}

function TimeRange({ start, end, cls }) {
  const same = !end || end === start;
  return (
    <div className={cls}>
      {start}{!same && <><span className="dash">–</span>{end}</>}
    </div>
  );
}

// ---------- 完整景點卡 ----------
function SpotCard({ s, status, openByDefault }) {
  const [open, setOpen] = useState(openByDefault);
  return (
    <div className={'spot' + (open ? ' open' : '')}>
      <div className="spot__head" onClick={() => setOpen(o => !o)}>
        <TimeRange start={s.start} end={s.end} cls="spot__time" />
        <div className="spot__head-main">
          {status === 'now' && <span className="now-badge"><span className="dot"></span>現在</span>}
          <div className="spot__title">{s.title}</div>
          {s.jp && <div className="spot__jp">{s.jp}</div>}
        </div>
        <span className="spot__chev"><UIIcon name="chevron" size={18} /></span>
      </div>

      <div className="spot__plan">{s.plan}</div>

      <div className="spot__body">
        <div className="spot__body-inner">
          <div className="detail">
            {s.tip && (
              <div className="detail__line">
                <span className="detail__ic tip"><Icon name="walk" size={15} /></span>
                <div>
                  <div className="detail__k">現場執行</div>
                  <div className="detail__v">{s.tip}</div>
                </div>
              </div>
            )}
            <div className="detail__line">
              <span className="detail__ic risk"><UIIcon name="sun" size={15} /></span>
              <div>
                <div className="detail__k">邊界風險查核</div>
                <div className="detail__v">{s.risk}</div>
              </div>
            </div>

            {s.ticket && <TicketTable ticket={s.ticket} />}

            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap' }}>
              {s.fare && <span className="fare-tag"><UIIcon name="check" size={12} />{s.fare}</span>}
              {s.map && (
                <a className="map-btn" href={mapHref(s.map)} target="_blank" rel="noopener">
                  <UIIcon name="pin" size={14} />在地圖開啟 ・ {s.jp ? s.jp.split(' ')[0] : s.title}
                </a>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function TicketTable({ ticket }) {
  return (
    <div>
      <div className="detail__k" style={{ marginBottom: '8px' }}>{ticket.title}</div>
      <div className="ticket">
        {ticket.rows.map((r, i) => (
          <div className="ticket__row" key={i}>
            <span className="ticket__dir">{r.dir}</span>
            <span className="ticket__train"><span className="jp">{r.train}</span></span>
            <span className="ticket__time">{r.time}</span>
            <span className="ticket__seat">{r.seat}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ---------- 交通精簡段 ----------
function TransitCard({ s, status, openByDefault }) {
  const [open, setOpen] = useState(openByDefault);
  const t = s.transit || {};
  return (
    <div className={'transit' + (open ? ' open' : '')}>
      <div className="transit__head" onClick={() => setOpen(o => !o)}>
        <TimeRange start={s.start} end={s.end} cls="transit__time" />
        <div className="transit__main">
          {status === 'now' && <span className="now-badge" style={{ marginBottom: '4px' }}><span className="dot"></span>現在</span>}
          <div className="transit__title">{s.title}</div>
          <div className="transit__meta">{t.line}</div>
        </div>
        <span className="transit__dur">{t.dur}</span>
        <span className="transit__chev"><UIIcon name="chevron" size={16} /></span>
      </div>
      <div className="transit__body">
        <div>
          <div className="transit__detail">
            <div className="transit__chips">
              {t.seat && <span className="chip">座位 <b>{t.seat}</b></span>}
              {t.dur && <span className="chip">車程 <b>{t.dur}</b></span>}
              {t.dirNote && <span className="chip">{t.dirNote}</span>}
            </div>
            <div className="transit__note">{s.plan}</div>
            <div className="transit__note" style={{ color: 'var(--lemon-soft)' }}>※ {s.risk}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { SpotCard, TransitCard, mapHref });
